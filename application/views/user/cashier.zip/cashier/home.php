<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Cashier - TOKO BELIMBING</title>
    <!-- Tell the browser to be responsive to screen width -->
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <!-- Bootstrap 3.3.6 -->
    <link rel="stylesheet" href="<?=base_url('assets/lte/plugins/fontawesome-free/css/all.min.css');?>">
    <link rel="stylesheet" href="<?=base_url('assets/lte/dist/css/adminlte.min.css');?>">
    <link rel="stylesheet" href="<?=site_url('assets/lte/sweetalert/sweetalert.css');?>" />
    <style>
    body {
    background-color: #f6f7fb;
    font-family: 'Poppins', sans-serif;
    font-size: 14px;
}

/* Header */
.cashier-header {
    background: #ffffff;
    box-shadow: 0 2px 6px rgba(0,0,0,0.08);
    padding: 10px 20px;
    display: flex;
    align-items: center;
    justify-content: space-between;
}
.cashier-header h5 {
    margin: 0;
    font-weight: 600;
    color: #222;
}
.cashier-info {
    font-size: 13px;
    color: #666;
}

/* Logout button hover */
.logout-btn img {
    cursor: pointer;
    transition: transform 0.2s ease;
}
.logout-btn img:hover {
    transform: scale(1.1);
}

/* Cart Panel */
.cart-panel {
    background: #fff;
    border-radius: 12px;
    padding: 10px;
    height: 100%;
    display: flex;
    flex-direction: column;
    box-shadow: 0 2px 6px rgba(0,0,0,0.05);
}

.cart-header {
    background: #f2f2f2;
    font-weight: 600;
    font-size: 12px;
    border-radius: 8px;
}

#detail_cart {
    flex: 1;
    overflow-y: auto;
    border: 1px solid #eee;
    border-radius: 8px;
    background-color: #fafafa;
    padding: 6px;
    margin-top: 6px;
}

/* Jumlah Total */
.amount-box {
    background: linear-gradient(90deg, #007bff, #0056d2);
    color: #fff;
    font-size: 1.4rem;
    font-weight: bold;
    border-radius: 8px;
    text-align: center;
    padding: 10px;
}

/* Buttons */
.btn-modern {
    border-radius: 10px;
    font-weight: 600;
    transition: all 0.2s;
}
.btn-modern:hover {
    transform: scale(1.03);
}

/* Product container */
#product-container {
    background: #ffffff;
    border-radius: 12px;
    box-shadow: 0 2px 6px rgba(0,0,0,0.05);
    padding: 12px;
    overflow-y: auto;
    height: 90%;
}

/* Tag chips area */
#tag-container {
    display: flex;
    flex-wrap: wrap;
    gap: 8px;
    margin-top: 5px;
}

/* --- Product Header Box --- */
.product-header-box {
    background: #ffffff;
    border-radius: 14px;
    padding: 14px 18px;
    box-shadow: 0 2px 8px rgba(0,0,0,0.05);
}

/* Input modern */
.modern-input {
    border-radius: 8px !important;
    border: 1px solid #d8dbe2;
    transition: all 0.2s;
}
.modern-input:focus {
    border-color: #4a6cf7;
    box-shadow: 0 0 0 3px rgba(74,108,247,0.2);
}

/* Reload button sejajar */
.reload-btn {
    border-radius: 8px;
    font-weight: 600;
    transition: 0.2s;
    white-space: nowrap;
}
.reload-btn:hover {
    background: #4a6cf7;
    color: #fff;
    border-color: #4a6cf7;
}

/* Tag chips */
.tag-chip {
    background-color: #4a6cf7 !important; /* biru elegan */
    color: #fff;
    padding: 5px 12px;
    border-radius: 20px;
    font-size: 13px;
    font-weight: 500;
    cursor: pointer;
    transition: all 0.2s ease-in-out;
}
.tag-chip:hover,
.tag-chip.active {
    background: #3755e0;
    transform: scale(1.05);
    box-shadow: 0 0 8px rgba(74,108,247,0.3);
}

/* Product list box */
.product-list-box {
    background: #ffffff;
    border-radius: 14px;
    padding: 14px;
    box-shadow: 0 2px 8px rgba(0,0,0,0.05);
    overflow-y: auto;
}

/* Scrollbar styling (opsional) */
.product-list-box::-webkit-scrollbar {
    width: 8px;
}
.product-list-box::-webkit-scrollbar-thumb {
    background: #ccc;
    border-radius: 10px;
}
.product-list-box::-webkit-scrollbar-thumb:hover {
    background: #999;
}




/* Footer bar - fix layout */
.footer-bar {
    background: #171718;
    color: #f5f5f7;
    padding: 10px 16px;
    border-radius: 10px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 10px;
    box-shadow: 0 -2px 6px rgba(0,0,0,0.1);
    margin-top: 10px;
}

.footer-bar .btn {
    border-radius: 8px;
    font-weight: 500;
    padding: 4px 10px;
}

.footer-marquee {
    flex: 1;
    text-align: center;
    font-weight: 500;
    letter-spacing: 0.5px;
}

.footer-marquee marquee {
    color: #00b4d8;
    font-weight: 600;
}

</style>
    <script>
        <?php date_default_timezone_set('Asia/Jakarta'); ?>
        var serverTime = new Date(<?=date('Y, m, d, H, i, s, 0');?>);
        var clientTime = new Date();
        var Diff = serverTime.getTime() - clientTime.getTime();
        function displayServerTime() {
            var time = new Date(new Date().getTime() + Diff);
            var h = String(time.getHours()).padStart(2, '0');
            var m = String(time.getMinutes()).padStart(2, '0');
            var s = String(time.getSeconds()).padStart(2, '0');
            document.getElementById("clock").innerHTML = h + ":" + m + ":" + s;
        }
    </script>
</head>

<body onLoad="setInterval('displayServerTime()',1000);">
    <div class="container-fluid vh-100 d-flex flex-column">
    <!-- HEADER -->
    <div class="cashier-header">
        <div class="d-flex align-items-center">
            <img src="<?=base_url('assets/img/png-clipart-sale.png');?>" style="width:50px;height:35px;margin-right:10px;">
            <div>
                <h5>TOKO BELIMBING</h5>
                <div class="cashier-info"><?=$qt->address?></div>
            </div>
        </div>
        <div class="d-flex align-items-center gap-3">
            <div>
                <div><strong>Cashier 1:</strong> <?=$nama?></div>
                <div><?=date('l, d-m-Y');?> | <span id="clock"></span></div>
            </div>
            <div class="logout-btn" onclick="logout()">
                <img src="<?=base_url('assets/img/logout.png');?>" style="width:40px;height:35px;">
            </div>
        </div>
    </div>

    <!-- MAIN CONTENT -->
    <div class="row flex-grow-1 mt-2">
        <!-- LEFT SIDE: CART -->
        <div class="col-md-4 d-flex flex-column">
            <div class="cart-panel">
                <table class="table table-sm cart-table mb-2">
                    <thead class="cart-header">
                        <tr>
                            <th>CART ID</th>
                            <th>STATUS</th>
                            <th>SOURCE</th>
                            <th>CLEAR</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td class="bg-warning fw-bold"><?=$qhc->id?></td>
                            <td class="bg-success text-white fw-bold"><?=strtoupper($qhc->status)?></td>
                            <td class="bg-success text-white fw-bold"><?=strtoupper($qhc->cart_source)?></td>
                            <td onclick="<?=$qhc->status == 'done'?'':'clearCart()'?>" class="bg-danger text-white text-center fw-bold" style="cursor:pointer;">
                                <?=$qhc->status == 'done'?'DONE':'CLEAR'?>
                            </td>
                        </tr>
                    </tbody>
                </table>

                <div class="mb-2">
                    <label class="small fw-bold">Customer</label>
                    <input id="customer_name" name="customer_name" class="form-control form-control-sm"
                        value="<?=$qhc->customer_name?>">
                </div>

                <div id="detail_cart" class="flex-grow-1"></div>

                <div class="mt-3">
                    <div class="d-flex justify-content-between align-items-center">
                        <div class="fw-bold text-end">Jumlah:</div>
                        <div class="amount-box">
                            <span id="amount-display"></span>
                            <input id="amount" type="hidden" readonly>
                        </div>
                    </div>
                </div>

                <div class="mt-3 d-flex gap-2">
                    <button onclick="closeOpenCart()" type="button"
                        class="btn btn-danger btn-modern w-50 <?=$qhc->status == 'done'?'':'d-none'?>">Close</button>
                    <button onclick="pay()" class="btn btn-primary btn-modern w-100" <?=$qhc->status == 'done'?'disabled':''?>>BAYAR</button>
                </div>
            </div>
        </div>

    <!-- RIGHT SIDE: PRODUCT LIST -->
<!-- RIGHT SIDE: PRODUCT LIST -->
<div class="col-md-8 d-flex flex-column">
    <div class="product-header-box mb-2">
        <div class="row g-2 align-items-end">
            <div class="col-md-4">
                <label class="form-label fw-semibold small text-secondary mb-1">SKU</label>
                <input id="input_sku" type="text" class="form-control form-control-sm modern-input" autofocus>
            </div>
            <div class="col-md-6">
                <label class="form-label fw-semibold small text-secondary mb-1">Search</label>
                <div class="d-flex align-items-center gap-2">
                    <input id="search" oninput="search()" type="text" class="form-control form-control-sm modern-input" placeholder="Cari produk...">
                    <button onclick="search('')" class="btn btn-outline-primary btn-sm reload-btn">
                        <i class="fas fa-sync-alt me-1"></i> Reload
                    </button>
                </div>
            </div>
        </div>

        <!-- TAGS -->
        <div class="col-md-12 mt-3">
            <div class="d-flex align-items-center flex-wrap">
                <span class="fw-semibold me-2 text-secondary">TAG:</span>
                <div id="tag-container" class="d-flex flex-wrap gap-2">
                    <span class="tag-chip" onclick="filterTag('ALAT MANDI')">ALAT MANDI</span>
                    <span class="tag-chip" onclick="filterTag('MINUMAN')">MINUMAN</span>
                    <span class="tag-chip" onclick="filterTag('PEMBALUT')">PEMBALUT</span>
                    <span class="tag-chip" onclick="filterTag('PET FOOD')">PET FOOD</span>
                    <span class="tag-chip" onclick="filterTag('ROKOK')">ROKOK</span>
                    <span class="tag-chip" onclick="filterTag('SABUN')">SABUN</span>
                    <span class="tag-chip" onclick="filterTag('SEMBAKO')">SEMBAKO</span>
                    <span class="tag-chip" onclick="filterTag('SPAREPART')">SPAREPART</span>
                </div>
            </div>
        </div>
    </div>

    <div id="product-container" class="product-list-box flex-grow-1 text-center">
        Loading ...
    </div>
</div>


    </div>
            </td>
        </tr>
        <tr>
            <div class="footer-bar mt-2">
    <div class="d-flex gap-2">
        <button class="btn btn-sm btn-primary text-xs" onclick="formcustomer()">DATA CUSTOMER</button>
        <button onclick="historysale()" class="btn btn-sm btn-primary text-xs">HISTORY SALE</button>
    </div>
    <div class="footer-marquee">
        <marquee>WELCOME BELIMBING STORE</marquee>
    </div>
</div>
            </td>
        </tr>
    </table>
    <div class="modal fade" id="modalxl">
        <div class="modal-dialog modal-md">
            <div class="modal-content ">
                <div id="modalcontent" class="modal-body">
                    TES
                </div>
            </div>
            <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
    </div>
    <div class="modal fade" id="modallg">
        <div class="modal-dialog modal-xl">
            <div class="modal-content ">
                <div id="modalcontentlg" class="modal-body">
                    TES
                </div>
            </div>
            <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
    </div>
</div>
    <!-- <script src="<?=site_url('assets/lte/jquery/jquery-2.2.3.min.js')?>"></script>
    <script src="<?=base_url('assets/lte/sweetalert/sweetalert.js')?>"></script> -->

    <script src="<?=base_url('assets/lte/jquery/jquery-2.1.3.min.js')?>"></script>
    <script src="<?=base_url('assets/lte/jquery/jquery-ui.js')?>"></script>
    <script src="<?=base_url('assets/lte/plugins/datatables/jquery.dataTables.min.js');?>"></script>
    <!-- jQuery -->
    <script src="<?=base_url('assets/lte/plugins/datatables/dataTables.jqueryui.min.js')?>"></script>
    <script src="<?=base_url('assets/lte/plugins/papaparse/papaparse.min.js');?>"></script>
    <script src="<?=base_url('assets/lte/plugins/datatables-editor/js/dataTables.editor.min.js?id='.time());?>">
    </script>
    <script src="<?=base_url('assets/lte/plugins/datatables-editor/js/editor.bootstrap4.min.js');?>"></script>
    <script src="<?=base_url('assets/lte/plugins/datatables-select/js/dataTables.select.min.js');?>"></script>
    <script src="<?=base_url('assets/lte/plugins/datatables-buttons/js/dataTables.buttons.min.js');?>"></script>
    <script src="<?=base_url('assets/lte/plugins/jszip/jszip.min.js');?>"></script>
    <script src="<?=base_url('assets/lte/plugins/pdfmake/pdfmake.min.js');?>"></script>
    <script src="<?=base_url('assets/lte/plugins/pdfmake/vfs_fonts.js');?>"></script>
    <script src="<?=base_url('assets/lte/plugins/datatables-buttons/js/buttons.html5.min.js');?>"></script>
    <script src="<?=base_url('assets/lte/plugins/datatables-buttons/js/buttons.print.min.js');?>"></script>
    <script src="<?=base_url('assets/lte/plugins/moment/moment.min.js');?>"></script>

    <script src="<?=base_url('assets/lte/plugins/overlayScrollbars/js/jquery.overlayScrollbars.min.js');?>"></script>
    <!-- Bootstrap 4 -->
    <script src="<?=base_url('assets/lte/plugins/bootstrap/js/bootstrap.bundle.min.js');?>"></script>
    <!-- DataTables -->
    <script src="<?=base_url('assets/lte/plugins/datatables-bs4/js/dataTables.bootstrap4.min.js');?>"></script>
    <script src="<?=base_url('assets/lte/plugins/datatables-responsive/js/dataTables.responsive.min.js');?>"></script>
    <script src="<?=base_url('assets/lte/plugins/SearchBuilder-1.3.0/js/dataTables.searchBuilder.min.js');?>"></script>
    <script src="<?=base_url('assets/lte/plugins/DateTime/js/dataTables.dateTime.min.js');?>"></script>
    <script src="<?=base_url('assets/lte/sweetalert/sweetalert.js')?>"></script>

    <link rel="stylesheet" href="//code.jquery.com/ui/1.13.2/themes/base/jquery-ui.css">
    <script src="https://code.jquery.com/ui/1.13.2/jquery-ui.js"></script>

    <script type="text/javascript">
    cv = '<?=$this->security->get_csrf_hash(); ?>';

    var cartid = $('#cartid').val();
    $(document).ready(function() {
        var tinggi = ($(window).height() - 130);
        $('#content').css('height', tinggi);
        $("#loading").fadeOut("slow");

        tag();
        search();



    });

    $(function() {
        var availableTags = [
            <?php foreach ($qtc as $key) { ?> '<?=$key->customer_name?>',
            <?php }?>
        ];
        $("#customer_name").autocomplete({
            source: availableTags
        });
    });



    $("#input_sku").on('keyup', function(e) {
        if (e.key === 'Enter' || e.keyCode === 13) {
            // Do something
            let sku = $("#input_sku").val().trim();
            $.ajax({
                type: "POST",
                url: "<?=base_url('cashier/additem?api='.$this->id_t); ?>",
                data: "cartid=" + cartid + "&sku=" + sku +
                    "&<?= $this->security->get_csrf_token_name(); ?>=" + cv,
                cache: false,
                dataType: 'json',
                success: function(res) {
                    if (res.success == true) {
                        console.log(res.success)
                        $("#modalxl").modal('hide');

                        location.reload();
                        getAmount()
                        $("#sku-status").text('');
                    } else {

                        $("#sku-status").text(res.message);
                    }
                },
                error: function(error) {
                    $('#product-container').html(error);
                }
            });
        }
    });



    $(window).resize(function() {
        var tinggi = ($(window).height() - 130);
        $('#content').css('height', tinggi);
    })

    function back() {
        swal({
                title: "Are you sure?",
                text: "Home Page",
                type: "warning",
                showCancelButton: true,
                confirmButtonClass: 'btn-danger',
                confirmButtonText: 'Yes',
                closeOnConfirm: false,
                //closeOnCancel: false
            },
            function() {
                window.location.href = "<?=base_url('sto/back?api='.$this->id_t); ?>";
            });

    }

    function logout() {
        swal({
                title: "Are you sure?",
                text: "Logout",
                type: "warning",
                showCancelButton: true,
                confirmButtonClass: 'btn-success',
                confirmButtonText: 'Yes',
                closeOnConfirm: false,
                //closeOnCancel: false
            },
            function() {
                window.location.href = "<?=base_url('action/logout?api='.$this->id_t); ?>";
            });
    }

    function pilih(cat, device) {
        swal({
                title: "Are you sure?",
                text: "STO " + cat.toUpperCase(),
                type: "warning",
                showCancelButton: true,
                confirmButtonClass: 'btn-success',
                confirmButtonText: 'Yes',
                closeOnConfirm: false,
                //closeOnCancel: false
            },
            function() {
                if (device == 'mobile') {
                    window.location.href = "<?= base_url('posting/start?pos='); ?>" + cat +
                        "<?= '&api=' . $this->id_t; ?>";
                } else {
                    window.location.href = "<?= base_url('postingpc/start?pos='); ?>" + cat +
                        "<?= '&api=' . $this->id_t; ?>";
                }


            });
    }

    function search() {
        // event.preventDefault()
        let product = document.getElementById('search').value
        $('#product-container').text('Loading...');
        console.log('tes')
        $.ajax({
            type: "POST",
            url: "<?=base_url('cashier/search?api='.$this->id_t); ?>",
            data: "product=" + product + "&<?= $this->security->get_csrf_token_name(); ?>=" + cv,
            cache: false,
            dataType: 'html',
            success: function(res) {
                if (res) {
                    $('#product-container').html(res);
                }
            },
            error: function(error) {
                $('#product-container').html(error);
            }
        });
    }
    // search()


    function editDetail(id) {

        $.ajax({
            type: "POST",
            url: "<?=base_url('cashier/formeditdetail?api='.$this->id_t); ?>",
            data: "id=" + id + "&<?= $this->security->get_csrf_token_name(); ?>=" + cv,
            cache: false,
            dataType: 'html',
            success: function(res) {
                if (res) {
                    $("#modalxl").modal('show');

                    $('#modalcontent').html(res);
                }
            },
            error: function(error) {
                $("#modalxl").modal('show');
            }
        });
    }

    function pay() {
        var customer_name = $('#customer_name').val();
        var cartid = $('#cartid').val();
        var amount = $('#amount').val();
        $.ajax({
            type: "POST",
            url: "<?=base_url('cashier/formpay?api='.$this->id_t); ?>",
            data: "cartid=" + cartid + "&amount=" + amount + "&customer_name=" + customer_name +
                "&<?= $this->security->get_csrf_token_name(); ?>=" + cv,
            cache: false,
            dataType: 'html',
            success: function(res) {
                if (res) {
                    $("#modalxl").modal('show');

                    $('#modalcontent').html(res);
                }
            },
            error: function(error) {
                $("#modalxl").modal('show');
            }
        });
    }

    function clearCart() {
        var cartid = $('#cartid').val();
        $.ajax({
            type: "POST",
            url: "<?=base_url('cashier/clearcart?api='.$this->id_t); ?>",
            data: "cartid=" + cartid + "&<?= $this->security->get_csrf_token_name(); ?>=" + cv,
            cache: false,
            dataType: 'json',
            success: function(res) {
                if (res.success == true) {

                    location.reload();
                    getAmount()
                } else {

                    $("#sku-status").text(res.message);
                }
            },
            error: function(error) {
                $("#modalxl").modal('show');
            }
        });
    }

    function tagsearch(tag) {
        // event.preventDefault()

        $('#product-container').text('Loading...');
        console.log('tes')
        $.ajax({
            type: "POST",
            url: "<?=base_url('cashier/tagsearch?api='.$this->id_t); ?>",
            data: "tag=" + tag + "&<?= $this->security->get_csrf_token_name(); ?>=" + cv,
            cache: false,
            dataType: 'html',
            success: function(res) {
                if (res) {
                    $('#product-container').html(res);
                }
            },
            error: function(error) {
                $('#product-container').html(error);
            }
        });
    }

    function tag() {
        // event.preventDefault()
        $('#tag-container').text('Loading...');
        console.log('tes')
        $.ajax({
            type: "POST",
            url: "<?=base_url('cashier/tag?api='.$this->id_t); ?>",
            data: "&<?= $this->security->get_csrf_token_name(); ?>=" + cv,
            cache: false,
            dataType: 'html',
            success: function(res) {
                if (res) {
                    $('#tag-container').html(res);
                }
            },
            error: function(error) {
                $('#tag-container').html(error);
            }
        });
    }
    // tag()

    function getMoneyChange() {
        var cash = $('#cash').val();
        var amount = $('#amount').val();
        var change = cash - parseFloat(amount);

        console.log(change)
        $('#change').text(new Intl.NumberFormat("id-ID", {
            style: "currency",
            currency: "IDR"
        }).format(change));
    }

    function printReceipt() {

        var cartid = $('#cartid').val();
        window.open("<?=base_url('cashier/print_receipt');?>?cartid=" + cartid + "&api=<?=$this->id_t;?>", "_blank");

    }

    function historysale() {
        $.ajax({
            type: "GET",
            url: "<?=base_url('cashier/historysale?api='.$this->id_t); ?>",
            // data: "cartid=" + cartid + "&amount=" + amount + "&customer_name=" + customer_name +"&<?= $this->security->get_csrf_token_name(); ?>=" + cv,
            cache: false,
            dataType: 'html',
            contentType: 'html',
            success: function(res) {


                $('#modalcontentlg').html(res);
                $("#modallg").modal('show');
            },
            error: function(error) {
                $("#modallg").modal('show');
            }
        });
    }

    function historysaleist() {
        $.ajax({
            type: "GET",
            url: "<?=base_url('cashier/historysaleist?api='.$this->id_t); ?>",
            // data: "cartid=" + cartid + "&amount=" + amount + "&customer_name=" + customer_name +"&<?= $this->security->get_csrf_token_name(); ?>=" + cv,
            cache: false,
            dataType: 'html',
            contentType: 'html',
            success: function(res) {


                $('#modalcontentlg').html(res);
                $("#modallg").modal('show');
            },
            error: function(error) {
                $("#modallg").modal('show');
            }
        });
    }

    function skipcart() {
        var cartid = $('#cartid').val();
        $.ajax({
            type: "POST",
            url: "<?=base_url('cashier/skipcart?api='.$this->id_t); ?>",
            data: "cartid=" + cartid + "&<?= $this->security->get_csrf_token_name(); ?>=" + cv,
            cache: false,
            dataType: 'json',
            success: function(res) {
                if (res.success == true) {
                    window.location.href = "<?=base_url('cashier?api='.$this->id_t); ?>";
                    getAmount()
                } else {

                    $("#sku-status").text(res.message);
                }
            },
            error: function(error) {
                $("#modalxl").modal('show');
            }
        });
    }

    function formcustomer() {
        $.ajax({
            type: "GET",
            url: "<?=base_url('cashier/formcustomer?api='.$this->id_t); ?>",
            // data: "cartid=" + cartid + "&amount=" + amount + "&customer_name=" + customer_name +"&<?= $this->security->get_csrf_token_name(); ?>=" + cv,
            cache: false,
            dataType: 'html',
            contentType: 'html',
            success: function(res) {


                $('#modalcontentlg').html(res);
                $("#modallg").modal('show');
            },
            error: function(error) {
                $("#modallg").modal('show');
            }
        });
    }

    function truncate() {
        // var cartid = $('#cartid').val();
        $.ajax({
            type: "GET",
            url: "<?=base_url('cashier/truncate?api='.$this->id_t); ?>",
            // data: "cartid=" + cartid + "&<?= $this->security->get_csrf_token_name(); ?>=" + cv,
            cache: false,
            dataType: 'json',
            success: function(res) {
                if (res.success == true) {

                    // location.reload();
                    window.location.href = "<?=base_url('cashier?api='.$this->id_t); ?>";

                } else {

                    $("#sku-status").text(res.message);
                }
            },
            error: function(error) {
                $("#modalxl").modal('show');
            }
        });
    }

    function closeOpenCart() {
        window.location.href = "<?=base_url('cashier?api='.$this->id_t); ?>";
    }
    </script>

</body>

</html>